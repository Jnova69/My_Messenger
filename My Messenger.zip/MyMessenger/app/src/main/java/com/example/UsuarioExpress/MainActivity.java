package com.example.UsuarioExpress;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mymessenger.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSection1 = findViewById(R.id.btn_section1);
        Button btnSection2 = findViewById(R.id.btn_section2);
        Button btnSection3 = findViewById(R.id.btn_section3);

        btnSection1.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, com.example.mymessenger.InterestsActivity.class);
            startActivity(intent);
        });


        btnSection2.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, com.example.mymessenger.RecommendationsActivity.class);
            startActivity(intent);
        });


        btnSection3.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, com.example.mymessenger.NewsActivity.class);
            startActivity(intent);
        });
    }
}
