package com.example.mymessenger;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InterestsActivity extends AppCompatActivity {
    private static final String TAG = "InterestsActivity";
    private static final String LAST_FM_API_KEY = "1580fb9b078c67f4ab8971a49b1378c5";
    private static final String LAST_FM_API_URL = "http://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks&api_key=" + LAST_FM_API_KEY + "&format=json";
    private static final String TMDB_API_KEY = "80436a5c02f795ac3af429978cb17245";
    private static final String TMDB_API_URL = "https://api.themoviedb.org/3/movie/now_playing?api_key=" + TMDB_API_KEY + "&language=es-ES";
    private static final String NYT_API_KEY = "aQNfVSaQFsb5kBaiRR3aDe3e3NkZmjJn";
    private static final String NYT_API_URL = "https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=" + NYT_API_KEY;

    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interests);
        Log.d(TAG, "onCreate: Iniciando InterestsActivity");

        requestQueue = Volley.newRequestQueue(this);

        ListView listView = findViewById(R.id.list_interests);
        String[] interests = {"Música", "Películas", "Libros", "Deportes", "Videojuegos", "Arte", "Cocina", "Viajes"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, interests);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = interests[position];
            Log.d(TAG, "onItemClick: Seleccionado " + selectedItem);
            switch (selectedItem) {
                case "Música":
                    fetchMusicTrends();
                    break;
                case "Películas":
                    fetchMovieTrends();
                    break;
                case "Libros":
                    fetchBookTrends();
                    break;
                default:
                    Toast.makeText(this, "Seleccionaste: " + selectedItem, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchMusicTrends() {
        // ... (código existente sin cambios) ...
    }

    private void fetchMovieTrends() {
        // ... (código existente sin cambios) ...
    }

    private void fetchBookTrends() {
        Log.d(TAG, "fetchBookTrends: Iniciando solicitud de libros recientes");
        Toast.makeText(this, "Cargando libros recientes...", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "fetchBookTrends: URL de la API: " + NYT_API_URL);

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                NYT_API_URL,
                null,
                response -> {
                    Log.d(TAG, "fetchBookTrends: Respuesta recibida");
                    try {
                        JSONObject results = response.getJSONObject("results");
                        if (!results.has("books")) {
                            throw new JSONException("No se encontró la clave 'books' en la respuesta");
                        }
                        JSONArray books = results.getJSONArray("books");
                        ArrayList<String> bookTitles = new ArrayList<>();
                        ArrayList<String> bookAuthors = new ArrayList<>();
                        ArrayList<String> bookCovers = new ArrayList<>();
                        ArrayList<String> bookDescriptions = new ArrayList<>();

                        for (int i = 0; i < books.length(); i++) {
                            JSONObject book = books.getJSONObject(i);

                            String title = book.getString("title");
                            String author = book.getString("author");
                            String coverUrl = book.getString("book_image");
                            String description = book.getString("description");

                            bookTitles.add(title);
                            bookAuthors.add(author);
                            bookCovers.add(coverUrl);
                            bookDescriptions.add(description);

                            Log.d(TAG, "fetchBookTrends: Procesado libro - Título: " + title);
                        }

                        Log.d(TAG, "fetchBookTrends: Procesados " + bookTitles.size() + " libros");
                        Intent intent = new Intent(this, BookTrendsActivity.class);
                        intent.putExtra("book_titles", bookTitles);
                        intent.putExtra("book_authors", bookAuthors);
                        intent.putExtra("book_covers", bookCovers);
                        intent.putExtra("book_descriptions", bookDescriptions);
                        startActivity(intent);

                    } catch (JSONException e) {
                        Log.e(TAG, "fetchBookTrends: Error al procesar JSON: " + e.getMessage(), e);
                        Toast.makeText(this, "Error al procesar datos de libros: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Log.e(TAG, "fetchBookTrends: Error de red: " + error.toString(), error);
                    if (error.networkResponse != null) {
                        Log.e(TAG, "fetchBookTrends: Código de error: " + error.networkResponse.statusCode);
                        Log.e(TAG, "fetchBookTrends: Datos de error: " + new String(error.networkResponse.data));
                    }
                    Toast.makeText(this, "Error de conexión al cargar libros: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Accept", "application/json");
                return headers;
            }
        };

        request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(
                10000, // 10 segundos de timeout
                1, // número máximo de reintentos
                1.0f // multiplicador de backoff
        ));

        requestQueue.add(request);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Limpiando recursos");
        if (requestQueue != null) {
            requestQueue.cancelAll(this);
        }
    }
}