package com.example.mymessenger;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NewsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        ListView listView = findViewById(R.id.list_news);
        String[] news = {
                "Nueva tecnología de baterías promete duplicar la duración",
                "Descubren una nueva especie de mamífero en la Amazonía",
                "Avances en la lucha contra el cambio climático",
                "Lanzamiento exitoso de misión espacial a Marte",
                "Breakthrough en inteligencia artificial para diagnóstico médico"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, news);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = news[position];
            Toast.makeText(getApplicationContext(), "Leyendo: " + selectedItem, Toast.LENGTH_SHORT).show();

        });
    }
}