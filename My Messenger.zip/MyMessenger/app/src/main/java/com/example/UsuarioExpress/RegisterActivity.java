package com.example.UsuarioExpress;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mymessenger.R;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText usernameEditText = findViewById(R.id.et_username_register);
        EditText passwordEditText = findViewById(R.id.et_password_register);
        Button registerButton = findViewById(R.id.btn_register_confirm);

        registerButton.setOnClickListener(v -> {

            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            getSharedPreferences("MyMessengerPrefs", MODE_PRIVATE).edit()
                    .putString("username", username)
                    .putString("password", password)
                    .apply();

            Toast.makeText(RegisterActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();


            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
    }