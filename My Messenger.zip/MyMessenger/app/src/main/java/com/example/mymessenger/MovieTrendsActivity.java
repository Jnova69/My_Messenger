package com.example.mymessenger;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class MovieTrendsActivity extends AppCompatActivity {
    private static final String TAG = "MovieTrendsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_trends);

        Log.d(TAG, "onCreate: Iniciando MovieTrendsActivity");

        ArrayList<String> movieTitles = getIntent().getStringArrayListExtra("movie_titles");
        ArrayList<String> moviePosters = getIntent().getStringArrayListExtra("movie_posters");
        ArrayList<String> movieOverviews = getIntent().getStringArrayListExtra("movie_overviews");

        if (movieTitles == null || moviePosters == null || movieOverviews == null) {
            Log.e(TAG, "onCreate: Datos de películas faltantes");
            finish();
            return;
        }

        Log.d(TAG, "onCreate: Número de películas recibidas: " + movieTitles.size());

        RecyclerView recyclerView = findViewById(R.id.recycler_movies);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MovieAdapter(movieTitles, moviePosters, movieOverviews));

        Log.d(TAG, "onCreate: RecyclerView configurado");
    }

    private static class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
        private final ArrayList<String> titles;
        private final ArrayList<String> posters;
        private final ArrayList<String> overviews;

        public MovieAdapter(ArrayList<String> titles, ArrayList<String> posters, ArrayList<String> overviews) {
            this.titles = titles;
            this.posters = posters;
            this.overviews = overviews;
        }

        @NonNull
        @Override
        public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_movie, parent, false);
            return new MovieViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
            holder.titleView.setText(titles.get(position));
            holder.overviewView.setText(overviews.get(position));

            Glide.with(holder.itemView.getContext())
                    .load(posters.get(position))
                    .into(holder.posterView);
        }

        @Override
        public int getItemCount() {
            return titles.size();
        }

        static class MovieViewHolder extends RecyclerView.ViewHolder {
            final ImageView posterView;
            final TextView titleView;
            final TextView overviewView;

            MovieViewHolder(View view) {
                super(view);
                posterView = view.findViewById(R.id.image_movie_poster);
                titleView = view.findViewById(R.id.text_movie_title);
                overviewView = view.findViewById(R.id.text_movie_overview);
            }
        }
    }
}
